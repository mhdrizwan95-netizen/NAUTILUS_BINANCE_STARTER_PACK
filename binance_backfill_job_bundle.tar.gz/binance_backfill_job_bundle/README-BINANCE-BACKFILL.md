
# Binance Historical Backfill (Automated)

This patch adds a **one‑shot backfill job** to your `data_ingester` service. It uses **CCXT** to call the Binance public API and writes OHLCV chunks into `/data/incoming/<symbol>/<tf>/`, registering every file in the **ledger** (`/shared/manifest.sqlite`). Duplicates are skipped via content hash; a per‑stream **watermark** advances to avoid overlap.

## Run it

```bash
# Build + run the backfill job once (Docker Compose)
docker compose -f docker-compose.yml -f compose.autotrain.yml -f compose.backfill.yml run --rm data_backfill
```

- Configure the time window with envs in `compose.backfill.yml`:
  - `SYMBOLS=BTC/USDT,ETH/USDT`
  - `TIMEFRAME=1m` (Binance supports: 1m, 3m, 5m, 15m, 30m, 1h, 2h, 4h, 1d, ...)
  - `START_TS` / `END_TS` in **milliseconds since epoch** (0 means “auto” → earliest / now)
  - `BATCH_LIMIT=1000` (Binance max per request)
  - `SLEEP_MS` extra padding between requests (in addition to CCXT rate limiting)

The job is **idempotent**:
- Each written file is **content‑addressed** and registered; duplicates are detected and deleted.
- A watermark `ingest:binance:<symbol>:<tf>` advances after each successful write.
- If you re‑run with overlapping windows, no duplication occurs.

## How it plugs into your training loop

- The **ml_service** trainer **claims** unprocessed files (`downloaded→processing`), trains, and then **marks** them processed and **deletes** them (if `DELETE_AFTER_PROCESS=true`).  
- Set `EXACTLY_ONCE=true` in the ML service to ensure **no bar is trained twice** across the entire history (strict mode).  
- Or use sliding‑window mode (`EXACTLY_ONCE=false`) for better HMM quality and robustness, still with **no duplicate files** and deduped bars within each window.

## Notes

- Public Binance OHLCV does **not** require API keys. If you add keys, they **won’t** change public klines limits, but can help with private endpoints.
- Rate limits are respected via CCXT’s `enableRateLimit` + `SLEEP_MS` buffer. If you see 429s, raise `SLEEP_MS` or reduce `BATCH_LIMIT`.
- For bulk multi‑year backfills, consider running the job **per symbol** (override `SYMBOLS`) to parallelize with multiple containers.
