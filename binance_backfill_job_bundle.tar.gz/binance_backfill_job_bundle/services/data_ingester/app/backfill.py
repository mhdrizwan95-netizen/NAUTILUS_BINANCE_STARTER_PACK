
import os
import time
from pathlib import Path
from typing import List
import ccxt
import pandas as pd
from loguru import logger

# shared ledger from autotrain stack
from common import manifest

def ms():
    return int(time.time() * 1000)

def parse_env_list(name: str, default: str) -> List[str]:
    return [s.strip() for s in os.getenv(name, default).split(",") if s.strip()]

def timeframe_ms(ex, tf: str) -> int:
    try:
        return int(ex.parse_timeframe(tf) * 1000)
    except Exception:
        # fallback for common TFs
        m = {"1m":60_000,"3m":180_000,"5m":300_000,"15m":900_000,"30m":1_800_000,
             "1h":3_600_000,"2h":7_200_000,"4h":14_400_000,"1d":86_400_000}
        return m.get(tf, 60_000)

def main():
    LEDGER_DB = os.getenv("LEDGER_DB", "/shared/manifest.sqlite")
    DATA_LANDING = os.getenv("DATA_LANDING", "/data/incoming")
    EXCHANGE = os.getenv("EXCHANGE", "binance")
    SYMBOLS = parse_env_list("SYMBOLS", "BTC/USDT")
    TIMEFRAME = os.getenv("TIMEFRAME", "1m")
    BATCH_LIMIT = int(os.getenv("BATCH_LIMIT", "1000"))
    START_TS = int(os.getenv("START_TS", "0"))  # ms; 0 -> from exchange earliest
    END_TS = int(os.getenv("END_TS", "0"))      # ms; 0 -> now
    SLEEP_MS = int(os.getenv("SLEEP_MS", "500"))# between calls (in addition to ccxt rateLimit)
    LOG_LEVEL = os.getenv("LOG_LEVEL", "INFO")

    logger.remove()
    logger.add(lambda msg: print(msg, end=""))
    logger.level(LOG_LEVEL)

    Path(DATA_LANDING).mkdir(parents=True, exist_ok=True)
    Path(LEDGER_DB).parent.mkdir(parents=True, exist_ok=True)
    manifest.init(LEDGER_DB)

    # Create exchange client
    if not hasattr(ccxt, EXCHANGE):
        raise RuntimeError(f"Exchange {EXCHANGE} not in CCXT")
    ex = getattr(ccxt, EXCHANGE)({
        "enableRateLimit": True,
    })

    tf_ms = timeframe_ms(ex, TIMEFRAME)
    end_target = END_TS if END_TS > 0 else ms()

    logger.info(f"Backfill start: {EXCHANGE} {SYMBOLS} {TIMEFRAME} "
                f"from {START_TS or 'exchange-epoch'} to {end_target} (ms), limit={BATCH_LIMIT}")

    total_rows = 0
    for sym in SYMBOLS:
        # Watermark for this stream
        wm_name = f"ingest:{EXCHANGE}:{sym}:{TIMEFRAME}"
        since = manifest.get_watermark(wm_name, default=START_TS, db_path=LEDGER_DB)
        if not since or since <= 0:
            # Fetch earliest if not provided
            try:
                markets = ex.load_markets()
                # no standard earliest endpoint; start from provided START_TS or a safe epoch
                if START_TS <= 0:
                    # choose 2017-08-17 (Binance launch) as a conservative default start
                    since = 1502928000000
            except Exception:
                since = START_TS if START_TS > 0 else 1502928000000

        logger.info(f"[{sym}] starting at {since} ms")

        while since < end_target:
            try:
                batch = ex.fetch_ohlcv(sym, timeframe=TIMEFRAME, since=since, limit=BATCH_LIMIT)
                if not batch:
                    logger.info(f"[{sym}] no more data from exchange (since={since}); stopping.")
                    break

                df = pd.DataFrame(batch, columns=["timestamp","open","high","low","close","volume"])
                # Guard against out-of-order/dup rows the API can return
                df = df.drop_duplicates(subset=["timestamp"]).sort_values("timestamp")
                t_start = int(df["timestamp"].min())
                t_end = int(df["timestamp"].max())

                # If exchange bounced us back, advance by one TF to avoid infinite loop
                if t_end <= since:
                    since += tf_ms
                    continue

                # Write CSV under data landing
                dst_dir = Path(DATA_LANDING)/sym.replace("/","_")/TIMEFRAME
                dst_dir.mkdir(parents=True, exist_ok=True)
                dst = dst_dir/f"{sym.replace('/','_')}__{TIMEFRAME}__{t_start}_{t_end}.csv"
                df.to_csv(dst, index=False)

                # Register in ledger (dedup by sha256)
                file_id, inserted = manifest.register_file(
                    path=str(dst), symbol=sym, timeframe=TIMEFRAME,
                    t_start=t_start, t_end=t_end, db_path=LEDGER_DB
                )
                if not inserted:
                    # Delete duplicate file to keep disk tidy
                    try: os.remove(dst)
                    except FileNotFoundError: pass
                    logger.debug(f"[{sym}] duplicate content skipped ({t_start}-{t_end})")
                else:
                    # Advance watermark to just after t_end
                    manifest.set_watermark(wm_name, t_end + 1, db_path=LEDGER_DB)
                    total_rows += len(df)
                    logger.info(f"[{sym}] +{len(df)} rows [{t_start}..{t_end}] (total={total_rows})")

                # Move 'since' forward
                since = t_end + 1

                # Respect rate limits
                time.sleep(max(SLEEP_MS, getattr(ex, 'rateLimit', 500))/1000.0)
            except ccxt.RateLimitExceeded as e:
                logger.warning(f"[{sym}] rate-limit: {e}; sleeping...")
                time.sleep(max(2.0, getattr(ex, 'rateLimit', 500)/1000.0))
            except ccxt.NetworkError as e:
                logger.warning(f"[{sym}] network error: {e}; retrying in 3s")
                time.sleep(3.0)
            except ccxt.ExchangeError as e:
                logger.warning(f"[{sym}] exchange error: {e}; retrying in 5s")
                time.sleep(5.0)
            except Exception as e:
                logger.exception(f"[{sym}] unexpected error: {e}")
                time.sleep(5.0)

    logger.info(f"Backfill finished. Total rows: {total_rows}")

if __name__ == "__main__":
    main()
