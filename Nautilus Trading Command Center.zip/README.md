
  # Nautilus Trading Command Center

  This is a code bundle for Nautilus Trading Command Center. The original project is available at https://www.figma.com/design/lFKMXdhG7MLDvMytUsmzEq/Nautilus-Trading-Command-Center.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  